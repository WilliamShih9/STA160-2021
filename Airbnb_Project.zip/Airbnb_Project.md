# 1 Data Visualization


```python
import pandas as pd
import numpy as np
from matplotlib import pyplot
```


```python
df = pd.read_csv("Airbnb_NYC_2019.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>host_id</th>
      <th>host_name</th>
      <th>neighbourhood_group</th>
      <th>neighbourhood</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>last_review</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2539</td>
      <td>Clean &amp; quiet apt home by the park</td>
      <td>2787</td>
      <td>John</td>
      <td>Brooklyn</td>
      <td>Kensington</td>
      <td>40.64749</td>
      <td>-73.97237</td>
      <td>Private room</td>
      <td>149</td>
      <td>1</td>
      <td>9</td>
      <td>2018-10-19</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2595</td>
      <td>Skylit Midtown Castle</td>
      <td>2845</td>
      <td>Jennifer</td>
      <td>Manhattan</td>
      <td>Midtown</td>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>Entire home/apt</td>
      <td>225</td>
      <td>1</td>
      <td>45</td>
      <td>2019-05-21</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3647</td>
      <td>THE VILLAGE OF HARLEM....NEW YORK !</td>
      <td>4632</td>
      <td>Elisabeth</td>
      <td>Manhattan</td>
      <td>Harlem</td>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>Private room</td>
      <td>150</td>
      <td>3</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>365</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3831</td>
      <td>Cozy Entire Floor of Brownstone</td>
      <td>4869</td>
      <td>LisaRoxanne</td>
      <td>Brooklyn</td>
      <td>Clinton Hill</td>
      <td>40.68514</td>
      <td>-73.95976</td>
      <td>Entire home/apt</td>
      <td>89</td>
      <td>1</td>
      <td>270</td>
      <td>2019-07-05</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5022</td>
      <td>Entire Apt: Spacious Studio/Loft by central park</td>
      <td>7192</td>
      <td>Laura</td>
      <td>Manhattan</td>
      <td>East Harlem</td>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>Entire home/apt</td>
      <td>80</td>
      <td>10</td>
      <td>9</td>
      <td>2018-11-19</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# check 
df.describe()
df = df[(df['price'] > 0) & (df['price'] <= 1000) & (df['minimum_nights'] <= 60) & (df['reviews_per_month'] <= 15)]
```


```python
import seaborn as sns
price_plot = sns.distplot(df['price'],color='b')
```

    C:\Users\williamshih\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    


    
![png](output_5_1.png)
    



```python
df2= df[df['price']> 69.000000]
```


```python
sns.distplot(df2['price'],color='b')
```

    C:\Users\williamshih\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    




    <AxesSubplot:xlabel='price', ylabel='Density'>




    
![png](output_7_2.png)
    



```python
df['neighbourhood_group'].unique()
```




    array(['Brooklyn', 'Manhattan', 'Queens', 'Staten Island', 'Bronx'],
          dtype=object)




```python
#Brooklyn
sub_1=df.loc[df['neighbourhood_group'] == 'Brooklyn']
price_sub1=sub_1[['price']]
#Manhattan
sub_2=df.loc[df['neighbourhood_group'] == 'Manhattan']
price_sub2=sub_2[['price']]
#Queens
sub_3=df.loc[df['neighbourhood_group'] == 'Queens']
price_sub3=sub_3[['price']]
#Staten Island
sub_4=df.loc[df['neighbourhood_group'] == 'Staten Island']
price_sub4=sub_4[['price']]
#Bronx
sub_5=df.loc[df['neighbourhood_group'] == 'Bronx']
price_sub5=sub_5[['price']]
#putting all the prices' dfs in the list
price_list_by_n=[price_sub1, price_sub2, price_sub3, price_sub4, price_sub5]
```


```python
#creating an empty list that we will append later with price distributions for each neighbourhood_group
p_l_b_n_2=[]
#creating list with known values in neighbourhood_group column
nei_list=['Brooklyn', 'Manhattan', 'Queens', 'Staten Island', 'Bronx']
#creating a for loop to get statistics for price ranges and append it to our empty list
for x in price_list_by_n:
    i=x.describe(percentiles=[.25, .50, .75])
    i=i.iloc[3:]
    i.reset_index(inplace=True)
    i.rename(columns={'index':'Stats'}, inplace=True)
    p_l_b_n_2.append(i)
#changing names of the price column to the area name for easier reading of the table    
p_l_b_n_2[0].rename(columns={'price':nei_list[0]}, inplace=True)
p_l_b_n_2[1].rename(columns={'price':nei_list[1]}, inplace=True)
p_l_b_n_2[2].rename(columns={'price':nei_list[2]}, inplace=True)
p_l_b_n_2[3].rename(columns={'price':nei_list[3]}, inplace=True)
p_l_b_n_2[4].rename(columns={'price':nei_list[4]}, inplace=True)
#finilizing our dataframe for final view    
stat_df=p_l_b_n_2
stat_df=[df.set_index('Stats') for df in stat_df]
stat_df=stat_df[0].join(stat_df[1:])
stat_df

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brooklyn</th>
      <th>Manhattan</th>
      <th>Queens</th>
      <th>Staten Island</th>
      <th>Bronx</th>
    </tr>
    <tr>
      <th>Stats</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>min</th>
      <td>10.0</td>
      <td>10.0</td>
      <td>10.0</td>
      <td>13.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>60.0</td>
      <td>90.0</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>45.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>93.0</td>
      <td>140.0</td>
      <td>72.0</td>
      <td>75.0</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>149.0</td>
      <td>200.0</td>
      <td>109.0</td>
      <td>105.0</td>
      <td>95.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1000.0</td>
      <td>1000.0</td>
      <td>1000.0</td>
      <td>625.0</td>
      <td>800.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
sub_6=df[df.price < 500]
```


```python
dims = (12, 6)
fig, ax = pyplot.subplots(figsize = dims)
viz_nei=sns.violinplot(data=sub_6, x='neighbourhood_group', y='price', ax=ax)
viz_nei.set_title('Density and distribution of prices for each neighborhood_group')
viz_nei.grid(axis = 'y')
fig = viz_nei.figure
fig.savefig('Density.png', dpi = 400)
```


    
![png](output_12_0.png)
    


First, we can state that Manhattan has the highest range of prices for the listings with $150 price as average observation, followed by Brooklyn with $90 per night. Queens and Staten Island appear to have very similar distributions, Bronx is the cheapest of them all.


```python
df2.dtypes
```




    id                                  int64
    name                               object
    host_id                             int64
    host_name                          object
    neighbourhood_group                object
    neighbourhood                      object
    latitude                          float64
    longitude                         float64
    room_type                          object
    price                               int64
    minimum_nights                      int64
    number_of_reviews                   int64
    last_review                        object
    reviews_per_month                 float64
    calculated_host_listings_count      int64
    availability_365                    int64
    dtype: object




```python
# numerical correlation
num_corr = df[['price','minimum_nights','number_of_reviews','reviews_per_month', 'calculated_host_listings_count','availability_365']].corr(method ='pearson')
dims = (10, 6)
fig, ax = pyplot.subplots(figsize = dims)
heat = sns.heatmap(num_corr, cmap="BuGn", annot = True, linewidths=0.5, ax = ax)
heat.set_title("Correlation Plot")
fig = heat.figure
fig.tight_layout()
fig.savefig("Correlation.png", dpi = 400)
```


    
![png](output_15_0.png)
    


reviews per month and number of reviews have relatively high correlation. Others columns don't obvious high correlation with each other


```python
import matplotlib.pyplot as plt
```


```python
viz_4=sub_6.plot(kind='scatter', x='longitude', y='latitude', label='availability_365', c='price',
                  cmap=plt.get_cmap('jet'), colorbar=True, alpha=0.4, figsize=(10,8))
viz_4.legend()
```




    <matplotlib.legend.Legend at 0x24472a41fa0>




    
![png](output_18_1.png)
    



```python
import urllib
#initializing the figure size
plt.figure(figsize=(10,8))
#loading the png NYC image found on Google and saving to my local folder along with the project
URL = 'https://upload.wikimedia.org/wikipedia/commons/e/ec/Neighbourhoods_New_York_City_Map.PNG'
try:
    import imageio
    nyc_image = imageio.imread(URL)
except:
    from PIL import Image
    import requests
    from io import BytesIO
    response = requests.get(URL)
    nyc_image = np.array(Image.open(BytesIO(response.content)))
#scaling the image based on the latitude and longitude max and mins for proper output
plt.imshow(nyc_image,zorder=0,extent=[-74.258, -73.7, 40.49,40.92])
ax=plt.gca()
#using scatterplot again
sub_6.plot(kind='scatter', x='longitude', y='latitude', label='availability_365', c='price', ax=ax, 
           cmap=plt.get_cmap('jet'), colorbar=True, alpha=0.4, zorder=5)
plt.grid(False)
plt.legend()
plt.savefig("Map.png", dpi = 400)
plt.show()
```


    
![png](output_19_0.png)
    



```python
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
# plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(df['calculated_host_listings_count'], df['minimum_nights'], df['price'], c='skyblue', s=60)
ax.set_xlabel('calculated_host_listings_count', fontsize=10, rotation=150)
ax.set_ylabel('minimum_nights')
ax.set_zlabel('price', fontsize=10, rotation=60)
plt.savefig("HostListingsMinimumNights3D.png", dpi = 400)
plt.show()
```


    
![png](output_20_0.png)
    



```python
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(df['minimum_nights'], df['availability_365'], df['price'], c='skyblue', s=60)
ax.set_xlabel('minimum_nights', fontsize=10, rotation=150)
ax.set_ylabel('availability_365')
ax.set_zlabel('price', fontsize=10, rotation=60)
plt.savefig("MinimumAvailablity365.png", dpi = 400)
plt.show()
```


    
![png](output_21_0.png)
    



```python
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(df['minimum_nights'], df['availability_365'], df['price'], c='skyblue', s=60)
ax.set_xlabel('minimum_nights', fontsize=10, rotation=150)
ax.set_ylabel('availability_365')
ax.set_zlabel('price', fontsize=10, rotation=60)
plt.show()
```


    
![png](output_22_0.png)
    


# 2. Data Preprocessing


```python
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
from scipy import stats
from sklearn import preprocessing
import geohash as gh
from sklearn.model_selection import train_test_split
import category_encoders as ce
```


```python
df = pd.read_csv("Airbnb_NYC_2019.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>host_id</th>
      <th>host_name</th>
      <th>neighbourhood_group</th>
      <th>neighbourhood</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>last_review</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2539</td>
      <td>Clean &amp; quiet apt home by the park</td>
      <td>2787</td>
      <td>John</td>
      <td>Brooklyn</td>
      <td>Kensington</td>
      <td>40.64749</td>
      <td>-73.97237</td>
      <td>Private room</td>
      <td>149</td>
      <td>1</td>
      <td>9</td>
      <td>2018-10-19</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2595</td>
      <td>Skylit Midtown Castle</td>
      <td>2845</td>
      <td>Jennifer</td>
      <td>Manhattan</td>
      <td>Midtown</td>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>Entire home/apt</td>
      <td>225</td>
      <td>1</td>
      <td>45</td>
      <td>2019-05-21</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3647</td>
      <td>THE VILLAGE OF HARLEM....NEW YORK !</td>
      <td>4632</td>
      <td>Elisabeth</td>
      <td>Manhattan</td>
      <td>Harlem</td>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>Private room</td>
      <td>150</td>
      <td>3</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>365</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3831</td>
      <td>Cozy Entire Floor of Brownstone</td>
      <td>4869</td>
      <td>LisaRoxanne</td>
      <td>Brooklyn</td>
      <td>Clinton Hill</td>
      <td>40.68514</td>
      <td>-73.95976</td>
      <td>Entire home/apt</td>
      <td>89</td>
      <td>1</td>
      <td>270</td>
      <td>2019-07-05</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5022</td>
      <td>Entire Apt: Spacious Studio/Loft by central park</td>
      <td>7192</td>
      <td>Laura</td>
      <td>Manhattan</td>
      <td>East Harlem</td>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>Entire home/apt</td>
      <td>80</td>
      <td>10</td>
      <td>9</td>
      <td>2018-11-19</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dtypes 
```




    id                                  int64
    name                               object
    host_id                             int64
    host_name                          object
    neighbourhood_group                object
    neighbourhood                      object
    latitude                          float64
    longitude                         float64
    room_type                          object
    price                               int64
    minimum_nights                      int64
    number_of_reviews                   int64
    last_review                        object
    reviews_per_month                 float64
    calculated_host_listings_count      int64
    availability_365                    int64
    dtype: object




```python
df.shape
```




    (48895, 16)



## 2.1 Dealing with missing values


```python
# check missing values 
df.isna().sum()
```




    id                                    0
    name                                 16
    host_id                               0
    host_name                            21
    neighbourhood_group                   0
    neighbourhood                         0
    latitude                              0
    longitude                             0
    room_type                             0
    price                                 0
    minimum_nights                        0
    number_of_reviews                     0
    last_review                       10052
    reviews_per_month                 10052
    calculated_host_listings_count        0
    availability_365                      0
    dtype: int64



We can keep the missing values for `name`, `host_name`, since we are not going to using these variables in the model anyways. Even if we were, it may be worth it to keep them in the model to decide what the output of a null host_name would be.
As for `last_review` and `reviews_per_month`, we believe that `last_month` is a variable that we would never include in the model. For `reviews_per_month`, we can replace all the missing values to 0, because 0 should be the correct value if a review has never been made for that listing.

The empty values for name, host_name, and last reviews can be dropped, since they seem non-menaingful to impute. We can replace the empty values for reviews per month with 0 values, becuase this means there is no review per month. 


```python
df['reviews_per_month'] = df['reviews_per_month'].fillna(0.00)
df['name'] = df['name'].fillna('')
df['host_name'] = df['host_name'].fillna('')
```


```python
#check missing values again 
df.isna().sum()
```




    id                                    0
    name                                  0
    host_id                               0
    host_name                             0
    neighbourhood_group                   0
    neighbourhood                         0
    latitude                              0
    longitude                             0
    room_type                             0
    price                                 0
    minimum_nights                        0
    number_of_reviews                     0
    last_review                       10052
    reviews_per_month                     0
    calculated_host_listings_count        0
    availability_365                      0
    dtype: int64




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>host_id</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4.889500e+04</td>
      <td>4.889500e+04</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
      <td>48895.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.901714e+07</td>
      <td>6.762001e+07</td>
      <td>40.728949</td>
      <td>-73.952170</td>
      <td>152.720687</td>
      <td>7.029962</td>
      <td>23.274466</td>
      <td>1.090910</td>
      <td>7.143982</td>
      <td>112.781327</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.098311e+07</td>
      <td>7.861097e+07</td>
      <td>0.054530</td>
      <td>0.046157</td>
      <td>240.154170</td>
      <td>20.510550</td>
      <td>44.550582</td>
      <td>1.597283</td>
      <td>32.952519</td>
      <td>131.622289</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.539000e+03</td>
      <td>2.438000e+03</td>
      <td>40.499790</td>
      <td>-74.244420</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>9.471945e+06</td>
      <td>7.822033e+06</td>
      <td>40.690100</td>
      <td>-73.983070</td>
      <td>69.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.040000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.967728e+07</td>
      <td>3.079382e+07</td>
      <td>40.723070</td>
      <td>-73.955680</td>
      <td>106.000000</td>
      <td>3.000000</td>
      <td>5.000000</td>
      <td>0.370000</td>
      <td>1.000000</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.915218e+07</td>
      <td>1.074344e+08</td>
      <td>40.763115</td>
      <td>-73.936275</td>
      <td>175.000000</td>
      <td>5.000000</td>
      <td>24.000000</td>
      <td>1.580000</td>
      <td>2.000000</td>
      <td>227.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3.648724e+07</td>
      <td>2.743213e+08</td>
      <td>40.913060</td>
      <td>-73.712990</td>
      <td>10000.000000</td>
      <td>1250.000000</td>
      <td>629.000000</td>
      <td>58.500000</td>
      <td>327.000000</td>
      <td>365.000000</td>
    </tr>
  </tbody>
</table>
</div>



## 2.2 Omit extreme outliers and invalid values

There are also be some erroneous values in the dataset. For example, there are instances where the price is 10,000 per day despite being a single private room.

For `price`, we omit from the dataset if the price is above 3,000 per day or costs 0 per day. For `minimum_nights`, we omit if the number of minimum nights is above 60 days per month. For `reviews_per_month`, we omit if the number is above 15 per month, as it is very unlikely a listing could get 15 reviews a month, which is a review every 2 days.


```python
fig = plt.figure(figsize = (6,3))
ax1 = fig.add_subplot(1,3,1)
ax1.boxplot(df['price'])
ax1.set_yscale('log')
ax1.axhline(y = 1000)
ax1.set_xticklabels(['Price'])
ax2 = fig.add_subplot(1,3,2)
ax2.set_yscale('log')
ax2.boxplot(df['minimum_nights'])
ax2.set_xticklabels(['Minimum Nights'])
ax2.axhline(y = 60)
ax3 = fig.add_subplot(1,3,3)
ax3.set_yscale('log')
ax3.axhline(y = 15)
ax3.boxplot(df['reviews_per_month'])
ax3.set_xticklabels(['Reviews Per Month'])
plt.tight_layout()
fig.suptitle("Box Plot and Extreme Outlier Cutoff (Blue Line)", y = 0.95)
plt.grid(axis = 'y')
plt.subplots_adjust(top = 0.85)
plt.savefig('outlier.png', dpi = 400)
plt.show()
```


    
![png](output_37_0.png)
    



```python
df_omit = df[(df['price'] > 0) & (df['price'] <= 1000) & (df['minimum_nights'] <= 60) & (df['reviews_per_month'] <= 15)]
```

## 2.3 What are some components that need to take into considerations for house price?

geography (`latitude`, `longitude`), `minimum_nights`, `number_of_reviews`, `reviews_per_month`, `calculated_host_listings_count`, `availability_365`. Thus we can exclude `id`, `host_id`, `last_review` from our considerations for training data. We also exclude `neigbourhood_group` from our analysis as we believe this too closely overlaps with coordinate data.


```python
# generate training data 
# drop unrelated information
# neighborhood has the same information as latitude and longitude, thus enighborhood can be dropped
df_relevant = df_omit.drop(['id','name', 'host_name', 'host_id','neighbourhood','last_review'], axis=1)
```


```python
df_relevant.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>neighbourhood_group</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Brooklyn</td>
      <td>40.64749</td>
      <td>-73.97237</td>
      <td>Private room</td>
      <td>149</td>
      <td>1</td>
      <td>9</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Manhattan</td>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>Entire home/apt</td>
      <td>225</td>
      <td>1</td>
      <td>45</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Manhattan</td>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>Private room</td>
      <td>150</td>
      <td>3</td>
      <td>0</td>
      <td>0.00</td>
      <td>1</td>
      <td>365</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Brooklyn</td>
      <td>40.68514</td>
      <td>-73.95976</td>
      <td>Entire home/apt</td>
      <td>89</td>
      <td>1</td>
      <td>270</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Manhattan</td>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>Entire home/apt</td>
      <td>80</td>
      <td>10</td>
      <td>9</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#check number of unique values in each columne to decide what processing technique to use 
df_relevant.nunique()
```




    neighbourhood_group                   5
    latitude                          18967
    longitude                         14664
    room_type                             3
    price                               569
    minimum_nights                       50
    number_of_reviews                   391
    reviews_per_month                   927
    calculated_host_listings_count       47
    availability_365                    366
    dtype: int64



## 2.4 One hot encoding for categorical variables


```python
print(df_relevant['room_type'].unique())
print(df_relevant['neighbourhood_group'].unique())
```

    ['Private room' 'Entire home/apt' 'Shared room']
    ['Brooklyn' 'Manhattan' 'Queens' 'Staten Island' 'Bronx']
    

Based on the number of unique values and data type for each column. We can apply the following encoding method for text preprocessing: 

1. one hot encoding for neighbor group
2. create grouping for latitude and longitude first? then encode?
3.label encode for room type since size matters
4. conduct normalization/ standardization for all continuous data


```python
#exclude label
df_relevant.drop(['price'], axis = 1, inplace= True)
```


```python
df_relevant.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>neighbourhood_group</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Brooklyn</td>
      <td>40.64749</td>
      <td>-73.97237</td>
      <td>Private room</td>
      <td>1</td>
      <td>9</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Manhattan</td>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>Entire home/apt</td>
      <td>1</td>
      <td>45</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Manhattan</td>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>Private room</td>
      <td>3</td>
      <td>0</td>
      <td>0.00</td>
      <td>1</td>
      <td>365</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Brooklyn</td>
      <td>40.68514</td>
      <td>-73.95976</td>
      <td>Entire home/apt</td>
      <td>1</td>
      <td>270</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Manhattan</td>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>Entire home/apt</td>
      <td>10</td>
      <td>9</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_relevant_encode = pd.get_dummies(df_relevant, prefix = ['neighbourhood_group', 'room_type'], columns = ['neighbourhood_group', 'room_type'])
df_relevant_label = pd.get_dummies(df_relevant, prefix = ['neighbourhood_group'], columns = ['neighbourhood_group'])
le = preprocessing.LabelEncoder()
le.fit(['Shared room','Private room','Entire home/apt'])
df_relevant_label['room_type'] = le.transform(df_relevant_label['room_type'])
```

## 2.5 Geohash for latitude and longitude


```python
# create geohash code for geographical data 
df_relevant_encode['geohash']=df_relevant_encode.apply(lambda x: gh.encode(x['latitude'], x['longitude'], precision=7), axis=1)
```


```python
df_relevant_encode.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>latitude</th>
      <th>longitude</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
      <th>neighbourhood_group_Bronx</th>
      <th>neighbourhood_group_Brooklyn</th>
      <th>neighbourhood_group_Manhattan</th>
      <th>neighbourhood_group_Queens</th>
      <th>neighbourhood_group_Staten Island</th>
      <th>room_type_Entire home/apt</th>
      <th>room_type_Private room</th>
      <th>room_type_Shared room</th>
      <th>geohash</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>40.64749</td>
      <td>-73.97237</td>
      <td>1</td>
      <td>9</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>dr5rhxw</td>
    </tr>
    <tr>
      <th>1</th>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>1</td>
      <td>45</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>dr5ru6y</td>
    </tr>
    <tr>
      <th>2</th>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>3</td>
      <td>0</td>
      <td>0.00</td>
      <td>1</td>
      <td>365</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>dr72jmj</td>
    </tr>
    <tr>
      <th>3</th>
      <td>40.68514</td>
      <td>-73.95976</td>
      <td>1</td>
      <td>270</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>dr5rmn8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>10</td>
      <td>9</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>dr72j75</td>
    </tr>
  </tbody>
</table>
</div>




```python
#drop latltitude longitude
df_relevant_encode.drop(['latitude', 'longitude'], axis = 1, inplace= True)
```


```python
df_relevant_encode.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
      <th>neighbourhood_group_Bronx</th>
      <th>neighbourhood_group_Brooklyn</th>
      <th>neighbourhood_group_Manhattan</th>
      <th>neighbourhood_group_Queens</th>
      <th>neighbourhood_group_Staten Island</th>
      <th>room_type_Entire home/apt</th>
      <th>room_type_Private room</th>
      <th>room_type_Shared room</th>
      <th>geohash</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>9</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>dr5rhxw</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>45</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>dr5ru6y</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>0</td>
      <td>0.00</td>
      <td>1</td>
      <td>365</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>dr72jmj</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>270</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>dr5rmn8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10</td>
      <td>9</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>dr72j75</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_relevant_encode.geohash.nunique()
# there are 10442 unique geographical location, should apply target encoding later
```




    10431




```python
X_col_names = df_relevant_encode.columns
X = df_relevant_encode.values.tolist()
y = df_omit['price'].tolist()
```

## 2.6 Split Train and Test Data (2/3, 1/3 split)

Split train data and test data for this one, with 67% in the training set and 33% in the testing set.


```python
#train test split 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
print(len(X_train))
print(len(X_test))
print(len(y_train))
print(len(y_test))
```

    32373
    15946
    32373
    15946
    


```python
#create train and test dataframe for target encoding later
df_train = pd.DataFrame(X_train)
df_test = pd.DataFrame(X_test)
df_test_keep = df_test
df_train.columns = X_col_names
df_test.columns = X_col_names
```

## 2.7 Transform Continuous Variables

Use `TargetEncoder` to encode the `geohash`. Also, transform the y-variable and x-variables if necessary into either normalized/standardized form.

Normalization is good to use when you know that the distribution of your data does not follow a Gaussian distribution. This can be useful in algorithms that do not assume any distribution of the data like K-Nearest Neighbors and Neural Networks.

Standardization, on the other hand, can be helpful in cases where the data follows a Gaussian distribution. However, this does not have to be necessarily true. Also, unlike normalization, standardization does not have a bounding range. So, even if you have outliers in your data, they will not be affected by standardization.


```python
# target encode on geolocations, since the amount of unique values are large
# if we look at price as a target, each row with the unique value of geolocation would be replaced with the average price for the house
encoder = ce.TargetEncoder(cols=['geohash'], smoothing=0, return_df=True)

df_train['coded_geo'] = encoder.fit_transform(df_train['geohash'], y_train)
df_test['coded_geo'] = encoder.transform(df_train['geohash'])
```

    C:\Users\williamshih\anaconda3\lib\site-packages\category_encoders\utils.py:21: FutureWarning: is_categorical is deprecated and will be removed in a future version.  Use is_categorical_dtype instead
      elif pd.api.types.is_categorical(cols):
    


```python
df_train.drop('geohash', axis=1, inplace= True)
df_test.drop('geohash', axis=1, inplace= True)
```

It turns out the y-variable could benefit from a log transformation, depending on what model we are using as the distribution of prices is close to a lognormal distribution.


```python
#one, two, three = stats.boxcox(y_train, alpha = 0.95)
# print(three)
#y_train = np.log(y_train)
#y_test = np.log(y_test)
```


```python
# concatenate train and test dataframes again for normalization or stanadardization
df_train['price'] = y_train
df_test['price'] = y_test
df_whole = pd.concat([df_train, df_test])
```


```python
# apply standarization or normalization on continuous values based on the data distribution
to_scale = ['minimum_nights', 'number_of_reviews', 'reviews_per_month',
       'calculated_host_listings_count', 'availability_365','coded_geo']
scaled_train = df_train.copy()
scaled_test = df_test.copy()
scaled_features = scaled_train[to_scale]
scaler = preprocessing.StandardScaler().fit(scaled_features)
scaled_train[to_scale] = scaler.transform(scaled_features)
scaled_test[to_scale] = scaler.transform(scaled_test[to_scale])
```


```python
# This is extra code in case room_type uses the label encode instead of one-hot encoding
# scaler2 = preprocessing.StandardScaler().fit(df_relevant_label['room_type'].values.reshape(-1,1))
# df_relevant_label['room_type'] = scaler2.transform(df_relevant_label['room_type'].values.reshape(-1,1))
```


```python
print(scaler.mean_, scaler.var_)
# print(scaler2.mean_, scaler2.var_)
```

    [  5.90578569  23.45883916   1.0982646    7.14419424 111.87177586
     145.06139662] [7.97672334e+01 1.97257864e+03 2.45885778e+00 1.07521505e+03
     1.72229072e+04 4.35186541e+03]
    


```python
scaled_train.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
      <th>neighbourhood_group_Bronx</th>
      <th>neighbourhood_group_Brooklyn</th>
      <th>neighbourhood_group_Manhattan</th>
      <th>neighbourhood_group_Queens</th>
      <th>neighbourhood_group_Staten Island</th>
      <th>room_type_Entire home/apt</th>
      <th>room_type_Private room</th>
      <th>room_type_Shared room</th>
      <th>coded_geo</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>3.237300e+04</td>
      <td>3.237300e+04</td>
      <td>3.237300e+04</td>
      <td>3.237300e+04</td>
      <td>3.237300e+04</td>
      <td>32373.000000</td>
      <td>32373.000000</td>
      <td>32373.000000</td>
      <td>32373.000000</td>
      <td>32373.000000</td>
      <td>32373.000000</td>
      <td>32373.000000</td>
      <td>32373.000000</td>
      <td>3.237300e+04</td>
      <td>32373.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>-5.897560e-16</td>
      <td>-2.222847e-16</td>
      <td>7.928357e-16</td>
      <td>1.951104e-16</td>
      <td>-6.364037e-16</td>
      <td>0.023044</td>
      <td>0.411701</td>
      <td>0.439317</td>
      <td>0.118463</td>
      <td>0.007475</td>
      <td>0.516511</td>
      <td>0.460075</td>
      <td>0.023415</td>
      <td>1.007733e-16</td>
      <td>141.079480</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.000015e+00</td>
      <td>1.000015e+00</td>
      <td>1.000015e+00</td>
      <td>1.000015e+00</td>
      <td>1.000015e+00</td>
      <td>0.150045</td>
      <td>0.492149</td>
      <td>0.496312</td>
      <td>0.323160</td>
      <td>0.086138</td>
      <td>0.499735</td>
      <td>0.498411</td>
      <td>0.151219</td>
      <td>1.000015e+00</td>
      <td>116.212547</td>
    </tr>
    <tr>
      <th>min</th>
      <td>-5.492832e-01</td>
      <td>-5.281890e-01</td>
      <td>-7.003906e-01</td>
      <td>-1.873774e-01</td>
      <td>-8.524468e-01</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-1.895770e+00</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>-5.492832e-01</td>
      <td>-5.056734e-01</td>
      <td>-6.748816e-01</td>
      <td>-1.873774e-01</td>
      <td>-8.524468e-01</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-7.096004e-01</td>
      <td>69.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>-4.373168e-01</td>
      <td>-4.156112e-01</td>
      <td>-4.580551e-01</td>
      <td>-1.873774e-01</td>
      <td>-5.171732e-01</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-6.036073e-02</td>
      <td>105.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>-1.014176e-01</td>
      <td>1.218454e-02</td>
      <td>3.263463e-01</td>
      <td>-1.568808e-01</td>
      <td>8.544009e-01</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>4.704330e-01</td>
      <td>175.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>6.056735e+00</td>
      <td>1.363410e+01</td>
      <td>8.597637e+00</td>
      <td>9.754535e+00</td>
      <td>1.928801e+00</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>8.973026e+00</td>
      <td>1000.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
scaled_test.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
      <th>neighbourhood_group_Bronx</th>
      <th>neighbourhood_group_Brooklyn</th>
      <th>neighbourhood_group_Manhattan</th>
      <th>neighbourhood_group_Queens</th>
      <th>neighbourhood_group_Staten Island</th>
      <th>room_type_Entire home/apt</th>
      <th>room_type_Private room</th>
      <th>room_type_Shared room</th>
      <th>coded_geo</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.00000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
      <td>15946.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>-0.008796</td>
      <td>-0.004718</td>
      <td>-0.005474</td>
      <td>0.000772</td>
      <td>0.000561</td>
      <td>0.020758</td>
      <td>0.414399</td>
      <td>0.444187</td>
      <td>0.11263</td>
      <td>0.008027</td>
      <td>0.519127</td>
      <td>0.456541</td>
      <td>0.024332</td>
      <td>0.004287</td>
      <td>141.892638</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.980365</td>
      <td>1.007051</td>
      <td>0.986433</td>
      <td>1.021041</td>
      <td>0.999243</td>
      <td>0.142576</td>
      <td>0.492633</td>
      <td>0.496891</td>
      <td>0.31615</td>
      <td>0.089237</td>
      <td>0.499650</td>
      <td>0.498123</td>
      <td>0.154083</td>
      <td>0.999950</td>
      <td>118.074721</td>
    </tr>
    <tr>
      <th>min</th>
      <td>-0.549283</td>
      <td>-0.528189</td>
      <td>-0.700391</td>
      <td>-0.187377</td>
      <td>-0.852447</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-1.895770</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>-0.549283</td>
      <td>-0.505673</td>
      <td>-0.674882</td>
      <td>-0.187377</td>
      <td>-0.852447</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-0.704295</td>
      <td>69.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>-0.325350</td>
      <td>-0.415611</td>
      <td>-0.458055</td>
      <td>-0.187377</td>
      <td>-0.524793</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-0.060361</td>
      <td>105.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>-0.101418</td>
      <td>0.012185</td>
      <td>0.326346</td>
      <td>-0.156881</td>
      <td>0.862021</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.478843</td>
      <td>175.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>6.056735</td>
      <td>13.138759</td>
      <td>8.623146</td>
      <td>9.754535</td>
      <td>1.928801</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.00000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>8.973026</td>
      <td>1000.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# correlation plot to decide variables 
scaled_train.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
      <th>neighbourhood_group_Bronx</th>
      <th>neighbourhood_group_Brooklyn</th>
      <th>neighbourhood_group_Manhattan</th>
      <th>neighbourhood_group_Queens</th>
      <th>neighbourhood_group_Staten Island</th>
      <th>room_type_Entire home/apt</th>
      <th>room_type_Private room</th>
      <th>room_type_Shared room</th>
      <th>coded_geo</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>minimum_nights</th>
      <td>1.000000</td>
      <td>-0.147990</td>
      <td>-0.223799</td>
      <td>0.308940</td>
      <td>0.233287</td>
      <td>-0.044966</td>
      <td>-0.068389</td>
      <td>0.118120</td>
      <td>-0.051498</td>
      <td>-0.018318</td>
      <td>0.137614</td>
      <td>-0.132417</td>
      <td>-0.018334</td>
      <td>0.095232</td>
      <td>0.038798</td>
    </tr>
    <tr>
      <th>number_of_reviews</th>
      <td>-0.147990</td>
      <td>1.000000</td>
      <td>0.595509</td>
      <td>-0.074129</td>
      <td>0.177020</td>
      <td>0.007786</td>
      <td>0.017814</td>
      <td>-0.045826</td>
      <td>0.035401</td>
      <td>0.015882</td>
      <td>-0.000076</td>
      <td>0.006629</td>
      <td>-0.021598</td>
      <td>-0.053203</td>
      <td>-0.056272</td>
    </tr>
    <tr>
      <th>reviews_per_month</th>
      <td>-0.223799</td>
      <td>0.595509</td>
      <td>1.000000</td>
      <td>-0.051926</td>
      <td>0.171753</td>
      <td>0.035298</td>
      <td>-0.022078</td>
      <td>-0.065375</td>
      <td>0.110712</td>
      <td>0.025982</td>
      <td>-0.022020</td>
      <td>0.021825</td>
      <td>0.000834</td>
      <td>-0.069650</td>
      <td>-0.056097</td>
    </tr>
    <tr>
      <th>calculated_host_listings_count</th>
      <td>0.308940</td>
      <td>-0.074129</td>
      <td>-0.051926</td>
      <td>1.000000</td>
      <td>0.230374</td>
      <td>-0.022763</td>
      <td>-0.123997</td>
      <td>0.153666</td>
      <td>-0.033151</td>
      <td>-0.012915</td>
      <td>0.111875</td>
      <td>-0.108345</td>
      <td>-0.012617</td>
      <td>0.187275</td>
      <td>0.132569</td>
    </tr>
    <tr>
      <th>availability_365</th>
      <td>0.233287</td>
      <td>0.177020</td>
      <td>0.171753</td>
      <td>0.230374</td>
      <td>1.000000</td>
      <td>0.060805</td>
      <td>-0.079609</td>
      <td>-0.005056</td>
      <td>0.086739</td>
      <td>0.052646</td>
      <td>-0.009922</td>
      <td>-0.007118</td>
      <td>0.056250</td>
      <td>0.052416</td>
      <td>0.119138</td>
    </tr>
    <tr>
      <th>neighbourhood_group_Bronx</th>
      <td>-0.044966</td>
      <td>0.007786</td>
      <td>0.035298</td>
      <td>-0.022763</td>
      <td>0.060805</td>
      <td>1.000000</td>
      <td>-0.128479</td>
      <td>-0.135947</td>
      <td>-0.056300</td>
      <td>-0.013329</td>
      <td>-0.054511</td>
      <td>0.043696</td>
      <td>0.036123</td>
      <td>-0.051393</td>
      <td>-0.074819</td>
    </tr>
    <tr>
      <th>neighbourhood_group_Brooklyn</th>
      <td>-0.068389</td>
      <td>0.017814</td>
      <td>-0.022078</td>
      <td>-0.123997</td>
      <td>-0.079609</td>
      <td>-0.128479</td>
      <td>1.000000</td>
      <td>-0.740495</td>
      <td>-0.306664</td>
      <td>-0.072600</td>
      <td>-0.066073</td>
      <td>0.072050</td>
      <td>-0.019122</td>
      <td>-0.298862</td>
      <td>-0.165228</td>
    </tr>
    <tr>
      <th>neighbourhood_group_Manhattan</th>
      <td>0.118120</td>
      <td>-0.045826</td>
      <td>-0.065375</td>
      <td>0.153666</td>
      <td>-0.005056</td>
      <td>-0.135947</td>
      <td>-0.740495</td>
      <td>1.000000</td>
      <td>-0.324490</td>
      <td>-0.076820</td>
      <td>0.154089</td>
      <td>-0.151875</td>
      <td>-0.008644</td>
      <td>0.438289</td>
      <td>0.287236</td>
    </tr>
    <tr>
      <th>neighbourhood_group_Queens</th>
      <td>-0.051498</td>
      <td>0.035401</td>
      <td>0.110712</td>
      <td>-0.033151</td>
      <td>0.086739</td>
      <td>-0.056300</td>
      <td>-0.306664</td>
      <td>-0.324490</td>
      <td>1.000000</td>
      <td>-0.031814</td>
      <td>-0.109761</td>
      <td>0.101958</td>
      <td>0.026679</td>
      <td>-0.186135</td>
      <td>-0.146237</td>
    </tr>
    <tr>
      <th>neighbourhood_group_Staten Island</th>
      <td>-0.018318</td>
      <td>0.015882</td>
      <td>0.025982</td>
      <td>-0.012915</td>
      <td>0.052646</td>
      <td>-0.013329</td>
      <td>-0.072600</td>
      <td>-0.076820</td>
      <td>-0.031814</td>
      <td>1.000000</td>
      <td>-0.003585</td>
      <td>0.004793</td>
      <td>-0.003952</td>
      <td>-0.029956</td>
      <td>-0.032014</td>
    </tr>
    <tr>
      <th>room_type_Entire home/apt</th>
      <td>0.137614</td>
      <td>-0.000076</td>
      <td>-0.022020</td>
      <td>0.111875</td>
      <td>-0.009922</td>
      <td>-0.054511</td>
      <td>-0.066073</td>
      <td>0.154089</td>
      <td>-0.109761</td>
      <td>-0.003585</td>
      <td>1.000000</td>
      <td>-0.954099</td>
      <td>-0.160042</td>
      <td>0.323605</td>
      <td>0.471616</td>
    </tr>
    <tr>
      <th>room_type_Private room</th>
      <td>-0.132417</td>
      <td>0.006629</td>
      <td>0.021825</td>
      <td>-0.108345</td>
      <td>-0.007118</td>
      <td>0.043696</td>
      <td>0.072050</td>
      <td>-0.151875</td>
      <td>0.101958</td>
      <td>0.004793</td>
      <td>-0.954099</td>
      <td>1.000000</td>
      <td>-0.142934</td>
      <td>-0.307364</td>
      <td>-0.442225</td>
    </tr>
    <tr>
      <th>room_type_Shared room</th>
      <td>-0.018334</td>
      <td>-0.021598</td>
      <td>0.000834</td>
      <td>-0.012617</td>
      <td>0.056250</td>
      <td>0.036123</td>
      <td>-0.019122</td>
      <td>-0.008644</td>
      <td>0.026679</td>
      <td>-0.003952</td>
      <td>-0.160042</td>
      <td>-0.142934</td>
      <td>1.000000</td>
      <td>-0.056362</td>
      <td>-0.101001</td>
    </tr>
    <tr>
      <th>coded_geo</th>
      <td>0.095232</td>
      <td>-0.053203</td>
      <td>-0.069650</td>
      <td>0.187275</td>
      <td>0.052416</td>
      <td>-0.051393</td>
      <td>-0.298862</td>
      <td>0.438289</td>
      <td>-0.186135</td>
      <td>-0.029956</td>
      <td>0.323605</td>
      <td>-0.307364</td>
      <td>-0.056362</td>
      <td>1.000000</td>
      <td>0.569732</td>
    </tr>
    <tr>
      <th>price</th>
      <td>0.038798</td>
      <td>-0.056272</td>
      <td>-0.056097</td>
      <td>0.132569</td>
      <td>0.119138</td>
      <td>-0.074819</td>
      <td>-0.165228</td>
      <td>0.287236</td>
      <td>-0.146237</td>
      <td>-0.032014</td>
      <td>0.471616</td>
      <td>-0.442225</td>
      <td>-0.101001</td>
      <td>0.569732</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
scaled_train_X = scaled_train.loc[:, scaled_train.columns != 'price'].values.tolist()
scaled_train_y = scaled_train['price'].tolist()

scaled_test_X = scaled_test.loc[:, scaled_train.columns != 'price'].values.tolist()
scaled_test_y = scaled_test['price'].tolist()
```

# 3.Model training


```python
# some helper functions to do plotting 
# get the raw features importance (aggregate all dummies)
def raw_feature_importance(importance_dataframe, num_pos, cate_list):
    # numercial feature importance
    num_importance = importance_dataframe.head(num_pos) 
    num_importance.reset_index(drop = True, inplace = True)

    cate_dict ={}
    for i in cate_list:
        summ = 0
        for (idx, row) in importance_dataframe.iterrows():
            if i in row.loc['Feature']:
                summ += row.loc['Importance']
        cate_dict[i] = summ 
    
    cate_importance = pd.DataFrame.from_dict(cate_dict, orient='index')
    cate_importance.rename(columns={0: 'Importance'}, inplace=True)
    cate_importance.reset_index(inplace = True)
    cate_importance.rename(index=str, columns={"index": "Feature"}, inplace = True)

    raw_feature_importances = pd.concat([num_importance, cate_importance])
    raw_feature_importances.sort_values(by=['Importance'], inplace = True, ascending=False)
    return raw_feature_importances

# feature importance
def plot_feature_importance(rank_importance,left_limit, color, alpha, size_L, size_H, title):
    plt.style.use('default')
    fig, ax = plt.subplots(1,1) 
    ax.barh(range(len(rank_importance['Feature'][0:left_limit])),rank_importance[0:left_limit]['Importance'],color=color,alpha=alpha)
    #ax.barh(rank_importance[0:left_limit]['Importance'],range(len(rank_importance['Feature'][0:left_limit])),color=color,alpha=alpha)
    ax.set_yticks(range(rank_importance[0:left_limit].shape[0]))
    ax.set_yticklabels(rank_importance[0:left_limit]['Feature'], rotation='horizontal', fontsize=12)    
    ax.set_ylabel('Features', fontsize = 16)
    ax.set_xlabel('Feature importance', fontsize = 16)
    ax.set_title(title, fontsize = 16)
    fig.set_size_inches(size_L, size_H)
    plt.tight_layout()
    plt.grid(axis = 'x')
    plt.savefig(title + '.png', dpi = 400)
    plt.show()
```

# 3.1  Quick LASSO for baseline
* Use Lasso regression for quick baseline
* Mean absolute percentage error (MAPE), mean absolute error (MAE), and the Mean absolute Deviation (MAD) are used as evaluation metric. 
* R-squared (R2_score), Mean Squared Log Error (MSLE), Mean Squared Error (MSE), and Median Absolute Error are used as additional evaluation metrics.


```python
import sklearn.metrics
import sklearn
get_ipython().magic(u'matplotlib inline')
import matplotlib.pyplot as plt
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LassoCV
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.metrics import mean_squared_error, r2_score
from math import sqrt
from sklearn.metrics.pairwise import cosine_similarity
from collections import defaultdict
from sklearn.metrics import mean_absolute_error, mean_squared_log_error, median_absolute_error
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV
```


```python
# Lasso model select the optimized hyperparameters
def lasso_best(scaled_train_X, scaled_train_y, title):
    alphas = np.logspace(-4,2,num=50)
    #Return numbers spaced evenly on a log scale.
    scores = np.empty_like(alphas)
    opt_a = float('-inf')
    max_score = float('-inf')
    for i, a in enumerate(alphas):
        lasso = Lasso(max_iter = 100000, tol = 0.01)
        lasso.set_params(alpha = a)
        lasso.fit(scaled_train_X, scaled_train_y)
        scores[i] = lasso.score(scaled_test_X, scaled_test_y) # get scores for test dataset
        # lasso.score() Return the coefficient of determination R^2 of the prediction.
        # The best possible score is 1.0 and it can be negative (because the model can be arbitrarily worse).
        # A constant model that always predicts the expected value of y, disregarding the input features, would get a R^2 score of 0.0.
        if scores[i] > max_score: # lasso.score is r2 
            max_score = scores[i]
            opt_a = a
            lasso_save = lasso
    plt.plot(alphas, scores, color='b', linestyle='dashed', marker='o',markerfacecolor='blue', markersize=6)
    plt.xlabel('Alpha')
    plt.ylabel('Score')
    plt.xscale('log')
    plt.grid(True)
    plt.title('Score vs. Alpha ('+ title +')')
    plt.savefig(title +'scorealpha.png', dpi = 400)
    plt.show()
    print ('The optimized alpha and score of Lasso linear is: ', opt_a, max_score)
    print(opt_a)
    return opt_a
```


```python
opt_a = lasso_best(scaled_train_X, scaled_train_y, 'Linear')
opt_a_log = lasso_best(scaled_train_X, np.log(scaled_train_y), 'Log')
opt_a_sqrt = lasso_best(scaled_train_X, np.sqrt(scaled_train_y), 'Sqrt')
```


    
![png](output_79_0.png)
    


    The optimized alpha and score of Lasso linear is:  0.0001 0.0679395479648699
    0.0001
    


    
![png](output_79_2.png)
    


    The optimized alpha and score of Lasso linear is:  0.0001 -1.3464462578298924
    0.0001
    


    
![png](output_79_4.png)
    


    The optimized alpha and score of Lasso linear is:  0.0001 -1.2081733718961942
    0.0001
    


```python
# use  optimal alpha, re-train the model
# Linear
lasso_f = Lasso(alpha = opt_a, max_iter = 100000)
lasso_f.fit(scaled_train_X, scaled_train_y)
lasso_pred = lasso_f.predict(scaled_test_X)
# Log
lasso_f_log = Lasso(alpha = opt_a_log, max_iter = 100000)
lasso_f_log.fit(scaled_train_X, np.log(scaled_train_y))
lasso_pred_log = lasso_f_log.predict(scaled_test_X)
# Sqrt
lasso_f_sqrt = Lasso(alpha = opt_a_sqrt, max_iter = 100000)
lasso_f_sqrt.fit(scaled_train_X, np.sqrt(scaled_train_y))
lasso_pred_sqrt = lasso_f_sqrt.predict(scaled_test_X)
```


```python
import yellowbrick
from yellowbrick.regressor import PredictionError
```


```python
# define MAD_ratio, and evalution result
def mean_absolute_devation(arr):
    # Calculate the sum of absolute deviation about mean.
    absSum = 0
    for i in range(0, len(arr)):
        absSum = absSum + abs(arr[i] - np.mean(arr))
    return absSum / len(arr)

def mean_absolute_deviation_ratio(y_true, y_pred):
    return mean_absolute_devation(y_pred)/(mean_absolute_devation(y_true)+0.1)

def evaluate(test_price, prediction):
    MAPE = mean_absolute_percentage_error(test_price,prediction)
    print('MAPE of 2019 Airbnb price is {}'.format(MAPE))  
    MAE = mean_absolute_error(test_price, prediction)
    print('MAE of 2019 Airbnb price is {}'.format(MAE))   
    MAD_ratio = mean_absolute_deviation_ratio(test_price,prediction)
    print('MAD ratio of prediction in 2019 Airbnb price is {}'.format(MAD_ratio))
    r2 = r2_score(test_price, prediction)
    print('R^2 of 2019 Airbnb price is {}'.format(r2))
    MSLE = mean_squared_log_error(test_price, prediction)
    print('MSLE of 2019 Airbnb price is {}'.format(MSLE))
    Median = median_absolute_error(test_price, prediction)
    print('Median Absolute Error of 2019 Airbnb price is {}'.format(Median))
    MSError = mean_squared_error(test_price, prediction)
    print('MSE of 2019 Airbnb price is {}'.format(MSError))
    return([MAPE, MAE, MAD_ratio, r2, MSLE, Median, MSError])
 
    
def plot_diff(test_price, prediction, title1, title2):    # plot the pred vs. actual
    plt.plot(prediction,'o', color='red', alpha=0.3, label = 'predicted price')
    plt.plot(test_price,'*', color='blue', alpha=0.5, label = 'actual price')
    plt.title(title1)
    plt.legend(loc='upper right')
    plt.show()

    plt.plot((prediction - test_price)
             ,'v', color='green')
    plt.title(title2)
    plt.show()

def visualize_diff(test_price, prediction, model_name):
    plt.plot(test_price, color = "red", alpha=0.3, label = 'actual price')
    plt.plot(prediction, color = "green", alpha=0.5, label = 'predicted_price' )
    plt.title("Pred vs. Actual in {}".format(model_name))
    plt.legend(loc="upper right")
    plt.show()
    
def visualize_boxplot_diff(test_price, prediction, split_by, cut_offs, model_name, group_name):
    plt.style.use('default')
    if cut_offs != None:
        split_by = pd.cut(split_by, bins = cut_offs[0], labels = cut_offs[1])
    residual = test_price - prediction
    fig, ax = plt.subplots(figsize = (10, 5))
    data = pd.DataFrame({'Residuals':residual, group_name:split_by})
    data.boxplot(column = ['Residuals'], by = group_name, ax = ax)
    fig.suptitle('Boxplot of Residuals Grouped by ' + model_name)
    plt.ylabel('Residuals (Actual - Predicted)')
    plt.savefig(model_name + '.png', dpi = 400)
    plt.show()
    
def visualize_regression_diff(test_price, prediction, model_name):
    plt.style.use('default')
    model_name = 'Actual vs Residuals for ' + model_name
    residual = test_price - prediction
    coef = np.polyfit(test_price, residual, 1)
    function = np.poly1d(coef)
    plt.plot(test_price, residual, 'yo', test_price, function(test_price), '--k')
    plt.title(model_name)
    plt.xlabel('Actual Price')
    plt.ylabel('Residual Price')
    plt.grid()
    plt.ticklabel_format(useOffset=False, style='plain')
    plt.savefig(model_name + '_diff.png', dpi = 400)
    plt.show()
    
def visualize_regression_actual(test_price, prediction, model_name):
    plt.style.use('default')
    model_name = 'Actual vs Prediction for ' + model_name
    coef = np.polyfit(test_price, prediction, 1)
    function = np.poly1d(coef)
    plt.plot(test_price, prediction, 'yo', test_price, function(test_price), '--k')
    plt.title(model_name)
    plt.xlabel('Actual Price')
    plt.ylabel('Prediction Price')
    plt.grid()
    plt.ticklabel_format(useOffset=False, style='plain')
    plt.savefig(model_name + '_actual.png', dpi = 400)
    plt.show()
    
```


```python
eval_grid = np.array([[0.000]*7 for i in range(17)])
eval_grid[0,:] = evaluate(scaled_test_y, np.mean(scaled_test_y).repeat(len(scaled_test_y)))
```

    MAPE of 2019 Airbnb price is 0.8052693039244664
    MAE of 2019 Airbnb price is 78.55573516343233
    MAD ratio of prediction in 2019 Airbnb price is 0.0
    R^2 of 2019 Airbnb price is 0.0
    MSLE of 2019 Airbnb price is 0.4958395063803054
    Median Absolute Error of 2019 Airbnb price is 61.89263765207576
    MSE of 2019 Airbnb price is 13940.765345269056
    


```python
lasso_pred = np.array([10 if i < 10 else i for i in lasso_pred])
lasso_pred_log = np.array([2.3 if i < 2.3 else i for i in lasso_pred_log])
lasso_pred_sqrt = np.array([3.16 if i < 3.16 else i for i in lasso_pred_sqrt])
eval_grid[1,:] = evaluate(scaled_test_y, lasso_pred)
eval_grid[2,:] = evaluate(scaled_test_y, np.exp(lasso_pred_log))
eval_grid[3,:] = evaluate(scaled_test_y, np.square(lasso_pred_sqrt))
```

    MAPE of 2019 Airbnb price is 0.6453609994498701
    MAE of 2019 Airbnb price is 72.18386876959124
    MAD ratio of prediction in 2019 Airbnb price is 0.6623722855462792
    R^2 of 2019 Airbnb price is 0.06850741892715428
    MSLE of 2019 Airbnb price is 0.4335030872330056
    Median Absolute Error of 2019 Airbnb price is 48.203455318522295
    MSE of 2019 Airbnb price is 12985.719493595554
    MAPE of 2019 Airbnb price is 0.4512752615258362
    MAE of 2019 Airbnb price is 61.614727652823525
    MAD ratio of prediction in 2019 Airbnb price is 0.5711622987259765
    R^2 of 2019 Airbnb price is 0.11816067755286197
    MSLE of 2019 Airbnb price is 0.291150659374325
    Median Absolute Error of 2019 Airbnb price is 33.240010638363756
    MSE of 2019 Airbnb price is 12293.515066466605
    MAPE of 2019 Airbnb price is 0.5212490047790349
    MAE of 2019 Airbnb price is 64.78850006610216
    MAD ratio of prediction in 2019 Airbnb price is 0.5972912254428446
    R^2 of 2019 Airbnb price is 0.12474971960975267
    MSLE of 2019 Airbnb price is 0.32375384945882557
    Median Absolute Error of 2019 Airbnb price is 38.83917419156903
    MSE of 2019 Airbnb price is 12201.658777301383
    


```python
visualize_boxplot_diff(scaled_test_y, lasso_pred, scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Lasso Linear Regression (Linear)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, np.exp(lasso_pred_log), scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Lasso Linear Regression (Log)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, np.square(lasso_pred_sqrt), scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Lasso Linear Regression (Sqrt)', 'Price Group')
```


    
![png](output_85_0.png)
    



    
![png](output_85_1.png)
    



    
![png](output_85_2.png)
    



```python
visualize_regression_diff(scaled_test_y, lasso_pred, 'Lasso Linear Regression (Linear)')
visualize_regression_diff(scaled_test_y, np.exp(lasso_pred_log), 'Lasso Linear Regression (Log)')
visualize_regression_diff(scaled_test_y, np.square(lasso_pred_sqrt), 'Lasso Linear Regression (Sqrt)')
```


    
![png](output_86_0.png)
    



    
![png](output_86_1.png)
    



    
![png](output_86_2.png)
    



```python
visualize_regression_actual(scaled_test_y, lasso_pred, 'Lasso Linear Regression (Linear)')
visualize_regression_actual(scaled_test_y, np.exp(lasso_pred_log), 'Lasso Linear Regression (Log)')
visualize_regression_actual(scaled_test_y, np.square(lasso_pred_sqrt), 'Lasso Linear Regression (Sqrt)')
```


    
![png](output_87_0.png)
    



    
![png](output_87_1.png)
    



    
![png](output_87_2.png)
    



```python
# get important features from linear regression
def get_importance_lasso(lasso_f, scaled_train, name):
    importance_lr_best = lasso_f.coef_
    names_lr_best = scaled_train.loc[:, scaled_train.columns != 'price'].columns.tolist()
    df_importantce_lr_best = pd.DataFrame({'Feature':names_lr_best, 'Importance':importance_lr_best})
    # plot feature importance
    rank_importance_lr_best = df_importantce_lr_best.sort_values('Importance', ascending=False)
    plot_feature_importance(rank_importance_lr_best,15, 'steelblue', 0.8, 10, 4, name)
get_importance_lasso(lasso_f, scaled_train, 'Feature importance for Lasso (Linear)')
get_importance_lasso(lasso_f_log, scaled_train, 'Feature importance for Lasso (Log)')
get_importance_lasso(lasso_f_sqrt, scaled_train, 'Feature importance for Lasso (Sqrt)')
```


    
![png](output_88_0.png)
    



    
![png](output_88_1.png)
    



    
![png](output_88_2.png)
    


# 3.2 OLS

OLS is added to see if LASSO performs better than OLS and the differences between the two results.


```python
# Linear
linear_f = LinearRegression()
linear_f.fit(scaled_train_X, scaled_train_y)
linear_pred = linear_f.predict(scaled_test_X)
# Log 
linear_f_log = LinearRegression()
linear_f_log.fit(scaled_train_X, np.log(scaled_train_y))
linear_pred_log = linear_f_log.predict(scaled_test_X)
# Sqrt
linear_f_sqrt = LinearRegression()
linear_f_sqrt.fit(scaled_train_X, np.sqrt(scaled_train_y))
linear_pred_sqrt = linear_f_sqrt.predict(scaled_test_X)
```


```python
linear_pred = np.array([10 if i < 10 else i for i in linear_pred])
linear_pred_log = np.array([2.3 if i < 2.3 else i for i in linear_pred_log])
linear_pred_sqrt = np.array([3.16 if i < 3.16 else i for i in linear_pred_sqrt])
eval_grid[4,:] = evaluate(scaled_test_y, linear_pred)
eval_grid[5,:] = evaluate(scaled_test_y, np.exp(linear_pred_log))
eval_grid[6,:] = evaluate(scaled_test_y, np.square(linear_pred_sqrt))
```

    MAPE of 2019 Airbnb price is 0.645359514985311
    MAE of 2019 Airbnb price is 72.1838146867491
    MAD ratio of prediction in 2019 Airbnb price is 0.6623752131737218
    R^2 of 2019 Airbnb price is 0.06850899287630141
    MSLE of 2019 Airbnb price is 0.4335040663062703
    Median Absolute Error of 2019 Airbnb price is 48.2039703637282
    MSE of 2019 Airbnb price is 12985.697551539828
    MAPE of 2019 Airbnb price is 0.45114942919946266
    MAE of 2019 Airbnb price is 61.604171576499716
    MAD ratio of prediction in 2019 Airbnb price is 0.5716229268154599
    R^2 of 2019 Airbnb price is 0.11846890354233175
    MSLE of 2019 Airbnb price is 0.2910325538866568
    Median Absolute Error of 2019 Airbnb price is 33.22558898674096
    MSE of 2019 Airbnb price is 12289.218160274095
    MAPE of 2019 Airbnb price is 0.5212140468720735
    MAE of 2019 Airbnb price is 64.78644063479211
    MAD ratio of prediction in 2019 Airbnb price is 0.5973652494958726
    R^2 of 2019 Airbnb price is 0.12479859173025876
    MSLE of 2019 Airbnb price is 0.32373703621664557
    Median Absolute Error of 2019 Airbnb price is 38.843246278618444
    MSE of 2019 Airbnb price is 12200.977462537483
    


```python
get_importance_lasso(linear_f, scaled_train, 'Feature importance for OLS (Linear)')
get_importance_lasso(linear_f_log, scaled_train, 'Feature importance for OLS (Log)')
get_importance_lasso(linear_f_sqrt, scaled_train, 'Feature importance for OLS (Sqrt)')
```


    
![png](output_92_0.png)
    



    
![png](output_92_1.png)
    



    
![png](output_92_2.png)
    


# 3.3 KNN


```python
# helper function for printing out grid search results 
def print_grid_search_metrics(gs):
    print ("Best score: " + str(gs.best_score_))
    print ("Best parameters set:")
    best_parameters = gs.best_params_
    for param_name in sorted(best_parameters.keys()):
        print(param_name + ':' + str(best_parameters[param_name]))
```


```python
#parameters = { 'n_neighbors':[10,12,14,16,20,25,30,35,40,45,50,55,60,65,70]}
#25, 40, 25 worked best for Linear, Log, and Sqrt respectively
parameters = { 'n_neighbors':[20,25,30,35,40] 
}
# Linear
Grid_KNN = GridSearchCV(KNeighborsRegressor(),parameters, cv=5)
Grid_KNN.fit(scaled_train_X, scaled_train_y)
print_grid_search_metrics(Grid_KNN)
best_KNN_model = Grid_KNN.best_estimator_
# Log
Grid_KNN = GridSearchCV(KNeighborsRegressor(),parameters, cv=5)
Grid_KNN.fit(scaled_train_X, np.log(scaled_train_y))
print_grid_search_metrics(Grid_KNN)
best_KNN_model_log = Grid_KNN.best_estimator_
# Sqrt
Grid_KNN = GridSearchCV(KNeighborsRegressor(),parameters, cv=5)
Grid_KNN.fit(scaled_train_X, np.sqrt(scaled_train_y))
print_grid_search_metrics(Grid_KNN)
best_KNN_model_sqrt = Grid_KNN.best_estimator_
```

    Best score: 0.4800937524298815
    Best parameters set:
    n_neighbors:40
    Best score: 0.6230012599283101
    Best parameters set:
    n_neighbors:25
    Best score: 0.572176684001171
    Best parameters set:
    n_neighbors:40
    


```python
knn_pred = best_KNN_model.predict(scaled_test_X)
knn_pred_log = best_KNN_model_log.predict(scaled_test_X)
knn_pred_sqrt = best_KNN_model_sqrt.predict(scaled_test_X)
```


```python
knn_pred = np.array([10 if i < 10 else i for i in knn_pred])
knn_pred_log = np.array([2.3 if i < 2.3 else i for i in knn_pred_log])
knn_pred_sqrt = np.array([3.16 if i < 3.16 else i for i in knn_pred_sqrt])
eval_grid[7,:] = evaluate(scaled_test_y, knn_pred)
eval_grid[8,:] = evaluate(scaled_test_y, np.exp(knn_pred_log))
eval_grid[9,:] = evaluate(scaled_test_y, np.square(knn_pred_sqrt))
```

    MAPE of 2019 Airbnb price is 0.5398022995164553
    MAE of 2019 Airbnb price is 65.41853442869684
    MAD ratio of prediction in 2019 Airbnb price is 0.686827014103283
    R^2 of 2019 Airbnb price is 0.1072570495652001
    MSLE of 2019 Airbnb price is 0.3245455868905331
    Median Absolute Error of 2019 Airbnb price is 37.275000000000006
    MSE of 2019 Airbnb price is 12445.519985654708
    MAPE of 2019 Airbnb price is 0.4492511737495444
    MAE of 2019 Airbnb price is 60.90785508304583
    MAD ratio of prediction in 2019 Airbnb price is 0.6191417148252534
    R^2 of 2019 Airbnb price is 0.14221298975553398
    MSLE of 2019 Airbnb price is 0.29271962664043955
    Median Absolute Error of 2019 Airbnb price is 31.949410229958836
    MSE of 2019 Airbnb price is 11958.207426038005
    MAPE of 2019 Airbnb price is 0.4885810351903921
    MAE of 2019 Airbnb price is 62.58899157837894
    MAD ratio of prediction in 2019 Airbnb price is 0.6476053263722958
    R^2 of 2019 Airbnb price is 0.13495251592274904
    MSLE of 2019 Airbnb price is 0.3033806561111084
    Median Absolute Error of 2019 Airbnb price is 34.481318370350735
    MSE of 2019 Airbnb price is 12059.423988036324
    


```python
visualize_boxplot_diff(scaled_test_y, knn_pred, scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for k-Nearest Neighbors (Linear)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, np.exp(knn_pred_log), scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for k-Nearest Neighbors (Log)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, np.square(knn_pred_sqrt), scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for k-Nearest Neighbors (Sqrt)', 'Price Group')
```


    
![png](output_98_0.png)
    



    
![png](output_98_1.png)
    



    
![png](output_98_2.png)
    



```python
visualize_regression_diff(scaled_test_y, knn_pred, 'k-Nearest Neighbors (Linear)')
visualize_regression_diff(scaled_test_y, np.exp(knn_pred_log), 'k-Nearest Neigbors (Log)')
visualize_regression_diff(scaled_test_y, np.square(knn_pred_sqrt), 'k-Nearest Neigbor (Sqrt)')
```


    
![png](output_99_0.png)
    



    
![png](output_99_1.png)
    



    
![png](output_99_2.png)
    



```python
visualize_regression_actual(scaled_test_y, knn_pred, 'k-Nearest Neighbors (Linear)')
visualize_regression_actual(scaled_test_y, np.exp(knn_pred_log), 'k-Nearest Neighbors (Log)')
visualize_regression_actual(scaled_test_y, np.square(knn_pred_sqrt), 'k-Nearest Neighbors (Sqrt)')
```


    
![png](output_100_0.png)
    



    
![png](output_100_1.png)
    



    
![png](output_100_2.png)
    



```python
# get important features from knn
from sklearn.inspection import permutation_importance
def get_importance_knn(best_KNN_model, scaled_test_X, scaled_test_y, scaled_train, name):
    knn_results = permutation_importance(best_KNN_model, scaled_test_X, scaled_test_y, scoring='neg_mean_squared_error')
    importance_knn_best = knn_results.importances_mean
    names_knn_best = scaled_train.loc[:, scaled_train.columns != 'price'].columns.tolist()
    df_importantce_knn_best = pd.DataFrame({'Feature':names_knn_best, 'Importance':importance_knn_best})
    # plot feature importance
    rank_importance_knn_best = df_importantce_knn_best.sort_values('Importance', ascending=False)
    plot_feature_importance(rank_importance_knn_best,15, 'steelblue', 0.8, 10, 4, name)
#get_importance_knn(best_KNN_model, scaled_test_X,scaled_test_y,scaled_train,  'Feature importance for kNN (linear)')
#get_importance_knn(best_KNN_model_log, scaled_test_X,np.log(scaled_test_y),scaled_train, 'Feature importance for kNN (log)')
#get_importance_knn(best_KNN_model_sqrt, scaled_test_X,np.sqrt(scaled_test_y),scaled_train, 'Feature importance for kNN (sqrt)')
```

# 3.4 SVM


```python
# Linear
Grid_SVM = SVR(C = 1, kernel = 'linear')
Grid_SVM.fit(scaled_train_X, scaled_train_y)
best_SVM_linmodel = Grid_SVM
# Linear
Grid_SVM = SVR(C = 1)
Grid_SVM.fit(scaled_train_X, scaled_train_y)
best_SVM_model = Grid_SVM
# Log
Grid_SVM = SVR(C = 1)
Grid_SVM.fit(scaled_train_X, np.log(scaled_train_y))
best_SVM_model_log = Grid_SVM
# Sqrt
Grid_SVM = SVR(C = 1)
Grid_SVM.fit(scaled_train_X, np.sqrt(scaled_train_y))
best_SVM_model_sqrt = Grid_SVM
```


```python
svm_pred = best_SVM_model.predict(scaled_test_X)
svm_pred_log = best_SVM_model_log.predict(scaled_test_X)
svm_pred_sqrt = best_SVM_model_sqrt.predict(scaled_test_X)
svm_linpred = best_SVM_linmodel.predict(scaled_test_X)
```


```python
svm_pred = np.array([10 if i < 10 else i for i in svm_pred])
svm_pred_log = np.array([2.3 if i < 2.3 else i for i in svm_pred_log])
svm_pred_sqrt = np.array([3.16 if i < 3.16 else i for i in svm_pred_sqrt])
svm_linpred = np.array([10 if i < 10 else i for i in svm_linpred])
eval_grid[10,:] = evaluate(scaled_test_y, svm_linpred)
eval_grid[11,:] = evaluate(scaled_test_y, svm_pred)
eval_grid[12,:] = evaluate(scaled_test_y, np.exp(svm_pred_log))
eval_grid[13,:] = evaluate(scaled_test_y, np.square(svm_pred_sqrt))
```

    MAPE of 2019 Airbnb price is 0.46584275819364146
    MAE of 2019 Airbnb price is 60.93175356904288
    MAD ratio of prediction in 2019 Airbnb price is 0.5004015892557963
    R^2 of 2019 Airbnb price is 0.15811832976047047
    MSLE of 2019 Airbnb price is 0.3009834196771076
    Median Absolute Error of 2019 Airbnb price is 35.9423786684047
    MSE of 2019 Airbnb price is 11736.474813292465
    MAPE of 2019 Airbnb price is 0.44910902977263106
    MAE of 2019 Airbnb price is 61.09621948763221
    MAD ratio of prediction in 2019 Airbnb price is 0.5135288159355884
    R^2 of 2019 Airbnb price is 0.1421325259173969
    MSLE of 2019 Airbnb price is 0.30052541209784195
    Median Absolute Error of 2019 Airbnb price is 34.176745292731994
    MSE of 2019 Airbnb price is 11959.329153524253
    MAPE of 2019 Airbnb price is 0.42664478082601043
    MAE of 2019 Airbnb price is 61.105739290747145
    MAD ratio of prediction in 2019 Airbnb price is 0.6134475800817827
    R^2 of 2019 Airbnb price is 0.12151045758105383
    MSLE of 2019 Airbnb price is 0.29634252219529766
    Median Absolute Error of 2019 Airbnb price is 31.310571495317305
    MSE of 2019 Airbnb price is 12246.816569135315
    MAPE of 2019 Airbnb price is 0.43135562996213006
    MAE of 2019 Airbnb price is 61.1068583862955
    MAD ratio of prediction in 2019 Airbnb price is 0.597254180290408
    R^2 of 2019 Airbnb price is 0.1291266677879087
    MSLE of 2019 Airbnb price is 0.2967407470923881
    Median Absolute Error of 2019 Airbnb price is 31.919363889275957
    MSE of 2019 Airbnb price is 12140.640769821308
    


```python
visualize_boxplot_diff(scaled_test_y, svm_linpred, scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Support Vector Machine (Linear,Linear Kernel)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, svm_pred, scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Support Vector Machine (Linear,Gaussian Kernel)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, np.exp(svm_pred_log), scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Support Vector Machine (Log,Gaussian Kernel)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, np.square(svm_pred_sqrt), scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Support Vector Machine (Sqrt,Gaussian Kernel)', 'Price Group')
```


    
![png](output_106_0.png)
    



    
![png](output_106_1.png)
    



    
![png](output_106_2.png)
    



    
![png](output_106_3.png)
    



```python
visualize_regression_diff(scaled_test_y, svm_linpred, 'Support Vector Machine (Linear,Linear Kernel)')
visualize_regression_diff(scaled_test_y, svm_pred, 'Support Vector Machine (Linear,Gaussian Kernel)')
visualize_regression_diff(scaled_test_y, np.exp(svm_pred_log), 'Support Vector Machine (Log,Gaussian Kernel)')
visualize_regression_diff(scaled_test_y, np.square(svm_pred_sqrt), 'Support Vector Machine (Sqrt,Gaussian Kernel)')
```


    
![png](output_107_0.png)
    



    
![png](output_107_1.png)
    



    
![png](output_107_2.png)
    



    
![png](output_107_3.png)
    



```python
visualize_regression_actual(scaled_test_y, np.exp(svm_pred_log), 'Support Vector Machine (Linear,Linear Kernel)')
visualize_regression_actual(scaled_test_y, svm_pred, 'Support Vector Machine (Linear,Gaussian Kernel)')
visualize_regression_actual(scaled_test_y, np.exp(svm_pred_log), 'Support Vector Machine (Log,Gaussian Kernel)')
visualize_regression_actual(scaled_test_y, np.square(svm_pred_sqrt), 'Support Vector Machine (Sqrt,Gaussian Kernel)')
```


    
![png](output_108_0.png)
    



    
![png](output_108_1.png)
    



    
![png](output_108_2.png)
    



    
![png](output_108_3.png)
    



```python
# get important features from SVM
def get_importance_SVM(best_SVM_model, scaled_train, name):
    importance_svm_best = abs(best_SVM_model.coef_[0])
    names_svm_best = scaled_train.loc[:, scaled_train.columns != 'price'].columns.tolist()
    df_importantce_svm_best = pd.DataFrame({'Feature':names_svm_best, 'Importance':importance_svm_best})
    # plot feature importance
    rank_importance_svm_best = df_importantce_svm_best.sort_values('Importance', ascending=False)
    plot_feature_importance(rank_importance_svm_best,15, 'steelblue', 0.8, 10, 4, 'Feature importance for SVM')

get_importance_SVM(best_SVM_linmodel, scaled_train, 'Feature importance for SVM (Linear,Linear Kernel)')
```


    
![png](output_109_0.png)
    


# 3.5 Random Forest Regression


```python
#param_grid = {'n_estimators': [40,60,80,120,160,200,240,280,320],
#         'max_depth': [20,25,30,35,40]}  
# Best was 160, max_depth = 20 for all three
param_grid = {'n_estimators': [320],
        'max_depth': [20]}  
Grid_RF = GridSearchCV(RandomForestRegressor(random_state=42), param_grid, refit = True, verbose = 3, cv =5) 
Grid_RF.fit(scaled_train_X, scaled_train_y)
print_grid_search_metrics(Grid_RF)
best_RF_model = Grid_RF.best_estimator_
best_RF_model.fit(scaled_train_X, scaled_train_y)

Grid_RF = GridSearchCV(RandomForestRegressor(random_state=42), param_grid, refit = True, verbose = 3, cv =5) 
Grid_RF.fit(scaled_train_X, np.log(scaled_train_y))
print_grid_search_metrics(Grid_RF)
best_RF_model_log = Grid_RF.best_estimator_
best_RF_model_log.fit(scaled_train_X, np.log(scaled_train_y))

Grid_RF = GridSearchCV(RandomForestRegressor(random_state=42), param_grid, refit = True, verbose = 3, cv =5) 
Grid_RF.fit(scaled_train_X, np.sqrt(scaled_train_y))
print_grid_search_metrics(Grid_RF)
best_RF_model_sqrt = Grid_RF.best_estimator_
best_RF_model_sqrt.fit(scaled_train_X, np.sqrt(scaled_train_y))
```

    Fitting 5 folds for each of 1 candidates, totalling 5 fits
    [CV 1/5] END ....max_depth=20, n_estimators=320;, score=0.484 total time=  54.3s
    [CV 2/5] END ....max_depth=20, n_estimators=320;, score=0.461 total time=  50.6s
    [CV 3/5] END ....max_depth=20, n_estimators=320;, score=0.469 total time=  42.8s
    [CV 4/5] END ....max_depth=20, n_estimators=320;, score=0.482 total time=  48.8s
    [CV 5/5] END ....max_depth=20, n_estimators=320;, score=0.462 total time=  58.5s
    Best score: 0.4717742384497604
    Best parameters set:
    max_depth:20
    n_estimators:320
    Fitting 5 folds for each of 1 candidates, totalling 5 fits
    [CV 1/5] END ....max_depth=20, n_estimators=320;, score=0.636 total time=  44.8s
    [CV 2/5] END ....max_depth=20, n_estimators=320;, score=0.632 total time=  41.1s
    [CV 3/5] END ....max_depth=20, n_estimators=320;, score=0.641 total time=  40.9s
    [CV 4/5] END ....max_depth=20, n_estimators=320;, score=0.638 total time=  44.2s
    [CV 5/5] END ....max_depth=20, n_estimators=320;, score=0.623 total time=  41.0s
    Best score: 0.6340046054685585
    Best parameters set:
    max_depth:20
    n_estimators:320
    Fitting 5 folds for each of 1 candidates, totalling 5 fits
    [CV 1/5] END ....max_depth=20, n_estimators=320;, score=0.580 total time=  46.6s
    [CV 2/5] END ....max_depth=20, n_estimators=320;, score=0.571 total time=  40.4s
    [CV 3/5] END ....max_depth=20, n_estimators=320;, score=0.580 total time=  40.7s
    [CV 4/5] END ....max_depth=20, n_estimators=320;, score=0.582 total time=  42.0s
    [CV 5/5] END ....max_depth=20, n_estimators=320;, score=0.566 total time=  41.2s
    Best score: 0.5755521523249326
    Best parameters set:
    max_depth:20
    n_estimators:320
    




    RandomForestRegressor(max_depth=20, n_estimators=320, random_state=42)




```python
rf_pred = best_RF_model.predict(scaled_test_X)
rf_pred_log = best_RF_model_log.predict(scaled_test_X)
rf_pred_sqrt = best_RF_model_sqrt.predict(scaled_test_X)
```


```python
rf_pred = np.array([10 if i < 10 else i for i in rf_pred])
rf_pred_log = np.array([2.3 if i < 2.3 else i for i in rf_pred_log])
rf_pred_sqrt = np.array([3.16 if i < 3.16 else i for i in rf_pred_sqrt])
eval_grid[14,:] = evaluate(scaled_test_y, rf_pred)
eval_grid[15,:] = evaluate(scaled_test_y, np.exp(rf_pred_log))
eval_grid[16,:] = evaluate(scaled_test_y, np.square(rf_pred_sqrt))
```

    MAPE of 2019 Airbnb price is 0.6126952513423345
    MAE of 2019 Airbnb price is 72.47642346385626
    MAD ratio of prediction in 2019 Airbnb price is 0.7764723344190206
    R^2 of 2019 Airbnb price is -0.013976123211010938
    MSLE of 2019 Airbnb price is 0.3913109554664751
    Median Absolute Error of 2019 Airbnb price is 42.46759919787873
    MSE of 2019 Airbnb price is 14135.603199390325
    MAPE of 2019 Airbnb price is 0.4890740861858039
    MAE of 2019 Airbnb price is 65.20054291102285
    MAD ratio of prediction in 2019 Airbnb price is 0.6628864586252305
    R^2 of 2019 Airbnb price is 0.08525567523101407
    MSLE of 2019 Airbnb price is 0.3386786145527546
    Median Absolute Error of 2019 Airbnb price is 35.8347316730841
    MSE of 2019 Airbnb price is 12752.23598252102
    MAPE of 2019 Airbnb price is 0.545290944432619
    MAE of 2019 Airbnb price is 68.46546488739604
    MAD ratio of prediction in 2019 Airbnb price is 0.7171415090096004
    R^2 of 2019 Airbnb price is 0.04711560561877659
    MSLE of 2019 Airbnb price is 0.36045131627475774
    Median Absolute Error of 2019 Airbnb price is 39.00842848152503
    MSE of 2019 Airbnb price is 13283.93774323745
    


```python
visualize_boxplot_diff(scaled_test_y, rf_pred, scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Random Forest (Linear)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, np.exp(rf_pred_log), scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Random Forest (Log)', 'Price Group')
visualize_boxplot_diff(scaled_test_y, np.square(rf_pred_sqrt), scaled_test_y, 
                       [[10, 50, 100, 150, 200, 250, 300, 350, 400, 1000],
                      ['10-50','50-00','100-150','150-200','200-250','250-300','300-350','350-400','400-1000']],
                      'Price Category for Random Forest (Sqrt)', 'Price Group')
```


    
![png](output_114_0.png)
    



    
![png](output_114_1.png)
    



    
![png](output_114_2.png)
    



```python
visualize_regression_diff(scaled_test_y, rf_pred, 'Random Forest (Linear)')
visualize_regression_diff(scaled_test_y, np.exp(rf_pred_log), 'Random Forest (Log)')
visualize_regression_diff(scaled_test_y, np.square(rf_pred_sqrt), 'Random Forest (Sqrt)')
```


    
![png](output_115_0.png)
    



    
![png](output_115_1.png)
    



    
![png](output_115_2.png)
    



```python
visualize_regression_actual(scaled_test_y, rf_pred, 'Random Forest (Linear)')
visualize_regression_actual(scaled_test_y, np.exp(rf_pred_log), 'Random Forest (Log)')
visualize_regression_actual(scaled_test_y, np.square(rf_pred_sqrt), 'Random Forest (Exp)')
```


    
![png](output_116_0.png)
    



    
![png](output_116_1.png)
    



    
![png](output_116_2.png)
    



```python
def get_importance_rf(best_RF_model, scaled_train, name):
    importance_rf_best = best_RF_model.feature_importances_
    names_rf_best = scaled_train.loc[:, scaled_train.columns != 'price'].columns.tolist()
    df_importantce_rf_best = pd.DataFrame({'Feature':names_rf_best, 'Importance':importance_rf_best})
    # plot feature importance
    rank_importance_rf_best = df_importantce_rf_best.sort_values('Importance', ascending=False)

    plot_feature_importance(rank_importance_rf_best,15, 'steelblue', 0.8, 10, 4, name)
get_importance_rf(best_RF_model, scaled_train, 'Feature importance for Random Forest (Linear)')
get_importance_rf(best_RF_model_log, scaled_train, 'Feature importance for Random Forest (Log)')
get_importance_rf(best_RF_model_sqrt, scaled_train, 'Feature importance for Random Forest (Exp)')
```


    
![png](output_117_0.png)
    



    
![png](output_117_1.png)
    



    
![png](output_117_2.png)
    


# Saving the Data


```python
df = pd.DataFrame(eval_grid, columns = ['MAPE', 'MAE', 'MAD_ratio', 'r2_score', 'MSLE', 'Median Absolute Error', 'MSE'],
                  index = ['Null','OLS (Linear)','OLS (Log)','OLS (Sqrt)','LASSO (Linear)', 'LASSO (Log)', 'LASSO (Sqrt)', 'kNN (Linear)', 'kNN (Log)', 'kNN (Sqrt)', 'SVM (Linear Kernel)','SVM (Linear/Gaussian)', 'SVM (Log/Gaussian)', 'SVM (Sqrt/Gaussian)',
        'Random Forest (Linear)', 'Random Forest (Log)', 'Random Forest (Sqrt)'])
df.to_csv("Metrics.csv", sep = ",")
```


```python
df.style.highlight_min(color = 'green', axis = 0).format("{:.3f}")
```




<style  type="text/css" >
#T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row0_col2,#T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row5_col4,#T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row8_col1,#T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row10_col6,#T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col0,#T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col5,#T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row14_col3{
            background-color:  green;
        }</style><table id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8" ><thead>    <tr>        <th class="blank level0" ></th>        <th class="col_heading level0 col0" >MAPE</th>        <th class="col_heading level0 col1" >MAE</th>        <th class="col_heading level0 col2" >MAD_ratio</th>        <th class="col_heading level0 col3" >r2_score</th>        <th class="col_heading level0 col4" >MSLE</th>        <th class="col_heading level0 col5" >Median Absolute Error</th>        <th class="col_heading level0 col6" >MSE</th>    </tr></thead><tbody>
                <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row0" class="row_heading level0 row0" >Null</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row0_col0" class="data row0 col0" >0.805</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row0_col1" class="data row0 col1" >78.556</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row0_col2" class="data row0 col2" >0.000</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row0_col3" class="data row0 col3" >0.000</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row0_col4" class="data row0 col4" >0.496</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row0_col5" class="data row0 col5" >61.893</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row0_col6" class="data row0 col6" >13940.765</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row1" class="row_heading level0 row1" >OLS (Linear)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row1_col0" class="data row1 col0" >0.645</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row1_col1" class="data row1 col1" >72.184</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row1_col2" class="data row1 col2" >0.662</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row1_col3" class="data row1 col3" >0.069</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row1_col4" class="data row1 col4" >0.434</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row1_col5" class="data row1 col5" >48.203</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row1_col6" class="data row1 col6" >12985.719</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row2" class="row_heading level0 row2" >OLS (Log)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row2_col0" class="data row2 col0" >0.451</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row2_col1" class="data row2 col1" >61.615</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row2_col2" class="data row2 col2" >0.571</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row2_col3" class="data row2 col3" >0.118</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row2_col4" class="data row2 col4" >0.291</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row2_col5" class="data row2 col5" >33.240</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row2_col6" class="data row2 col6" >12293.515</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row3" class="row_heading level0 row3" >OLS (Sqrt)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row3_col0" class="data row3 col0" >0.521</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row3_col1" class="data row3 col1" >64.789</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row3_col2" class="data row3 col2" >0.597</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row3_col3" class="data row3 col3" >0.125</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row3_col4" class="data row3 col4" >0.324</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row3_col5" class="data row3 col5" >38.839</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row3_col6" class="data row3 col6" >12201.659</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row4" class="row_heading level0 row4" >LASSO (Linear)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row4_col0" class="data row4 col0" >0.645</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row4_col1" class="data row4 col1" >72.184</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row4_col2" class="data row4 col2" >0.662</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row4_col3" class="data row4 col3" >0.069</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row4_col4" class="data row4 col4" >0.434</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row4_col5" class="data row4 col5" >48.204</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row4_col6" class="data row4 col6" >12985.698</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row5" class="row_heading level0 row5" >LASSO (Log)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row5_col0" class="data row5 col0" >0.451</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row5_col1" class="data row5 col1" >61.604</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row5_col2" class="data row5 col2" >0.572</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row5_col3" class="data row5 col3" >0.118</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row5_col4" class="data row5 col4" >0.291</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row5_col5" class="data row5 col5" >33.226</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row5_col6" class="data row5 col6" >12289.218</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row6" class="row_heading level0 row6" >LASSO (Sqrt)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row6_col0" class="data row6 col0" >0.521</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row6_col1" class="data row6 col1" >64.786</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row6_col2" class="data row6 col2" >0.597</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row6_col3" class="data row6 col3" >0.125</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row6_col4" class="data row6 col4" >0.324</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row6_col5" class="data row6 col5" >38.843</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row6_col6" class="data row6 col6" >12200.977</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row7" class="row_heading level0 row7" >kNN (Linear)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row7_col0" class="data row7 col0" >0.540</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row7_col1" class="data row7 col1" >65.419</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row7_col2" class="data row7 col2" >0.687</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row7_col3" class="data row7 col3" >0.107</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row7_col4" class="data row7 col4" >0.325</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row7_col5" class="data row7 col5" >37.275</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row7_col6" class="data row7 col6" >12445.520</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row8" class="row_heading level0 row8" >kNN (Log)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row8_col0" class="data row8 col0" >0.449</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row8_col1" class="data row8 col1" >60.908</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row8_col2" class="data row8 col2" >0.619</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row8_col3" class="data row8 col3" >0.142</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row8_col4" class="data row8 col4" >0.293</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row8_col5" class="data row8 col5" >31.949</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row8_col6" class="data row8 col6" >11958.207</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row9" class="row_heading level0 row9" >kNN (Sqrt)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row9_col0" class="data row9 col0" >0.489</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row9_col1" class="data row9 col1" >62.589</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row9_col2" class="data row9 col2" >0.648</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row9_col3" class="data row9 col3" >0.135</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row9_col4" class="data row9 col4" >0.303</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row9_col5" class="data row9 col5" >34.481</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row9_col6" class="data row9 col6" >12059.424</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row10" class="row_heading level0 row10" >SVM (Linear Kernel)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row10_col0" class="data row10 col0" >0.466</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row10_col1" class="data row10 col1" >60.932</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row10_col2" class="data row10 col2" >0.500</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row10_col3" class="data row10 col3" >0.158</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row10_col4" class="data row10 col4" >0.301</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row10_col5" class="data row10 col5" >35.942</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row10_col6" class="data row10 col6" >11736.475</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row11" class="row_heading level0 row11" >SVM (Linear/Gaussian)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row11_col0" class="data row11 col0" >0.449</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row11_col1" class="data row11 col1" >61.096</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row11_col2" class="data row11 col2" >0.514</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row11_col3" class="data row11 col3" >0.142</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row11_col4" class="data row11 col4" >0.301</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row11_col5" class="data row11 col5" >34.177</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row11_col6" class="data row11 col6" >11959.329</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row12" class="row_heading level0 row12" >SVM (Log/Gaussian)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col0" class="data row12 col0" >0.427</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col1" class="data row12 col1" >61.106</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col2" class="data row12 col2" >0.613</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col3" class="data row12 col3" >0.122</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col4" class="data row12 col4" >0.296</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col5" class="data row12 col5" >31.311</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row12_col6" class="data row12 col6" >12246.817</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row13" class="row_heading level0 row13" >SVM (Sqrt/Gaussian)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row13_col0" class="data row13 col0" >0.431</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row13_col1" class="data row13 col1" >61.107</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row13_col2" class="data row13 col2" >0.597</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row13_col3" class="data row13 col3" >0.129</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row13_col4" class="data row13 col4" >0.297</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row13_col5" class="data row13 col5" >31.919</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row13_col6" class="data row13 col6" >12140.641</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row14" class="row_heading level0 row14" >Random Forest (Linear)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row14_col0" class="data row14 col0" >0.613</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row14_col1" class="data row14 col1" >72.476</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row14_col2" class="data row14 col2" >0.776</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row14_col3" class="data row14 col3" >-0.014</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row14_col4" class="data row14 col4" >0.391</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row14_col5" class="data row14 col5" >42.468</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row14_col6" class="data row14 col6" >14135.603</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row15" class="row_heading level0 row15" >Random Forest (Log)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row15_col0" class="data row15 col0" >0.489</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row15_col1" class="data row15 col1" >65.201</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row15_col2" class="data row15 col2" >0.663</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row15_col3" class="data row15 col3" >0.085</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row15_col4" class="data row15 col4" >0.339</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row15_col5" class="data row15 col5" >35.835</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row15_col6" class="data row15 col6" >12752.236</td>
            </tr>
            <tr>
                        <th id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8level0_row16" class="row_heading level0 row16" >Random Forest (Sqrt)</th>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row16_col0" class="data row16 col0" >0.545</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row16_col1" class="data row16 col1" >68.465</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row16_col2" class="data row16 col2" >0.717</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row16_col3" class="data row16 col3" >0.047</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row16_col4" class="data row16 col4" >0.360</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row16_col5" class="data row16 col5" >39.008</td>
                        <td id="T_0b56127a_abd4_11eb_aeaa_b2740532d4a8row16_col6" class="data row16 col6" >13283.938</td>
            </tr>
    </tbody></table>




```python
all_data = pd.DataFrame({'Actual':scaled_test_y,
              'Null':np.mean(scaled_test_y).repeat(len(scaled_test_y)), 
              'OLS(Linear)':linear_pred,
              'OLS(Log)':np.exp(linear_pred_log),
              'OLS(Sqrt)':np.square(linear_pred_sqrt),
              'LASSO(Linear)':lasso_pred,
              'LASSO(Log)':np.exp(lasso_pred_log),
              'LASSO(Sqrt)':np.square(lasso_pred_sqrt),
              'kNN(Linear)':knn_pred,
              'kNN(Log)':np.exp(knn_pred_log),
              'kNN(Sqrt)':np.square(knn_pred_sqrt),
              'SVM(Linear Kernel)':svm_linpred,
              'SVM(Linear/Gaussian)':svm_pred,
              'SVM(Log/Gaussian)':np.exp(svm_pred_log),
              'SVM(Sqrt/Gaussian)':np.square(svm_pred_sqrt),
              'RandomForest(Linear)':rf_pred,
              'RandomForest(Log)':np.exp(rf_pred_log),
              'RandomForest(Sqrt)':np.square(rf_pred_sqrt)})
all_data.to_csv("TestModelData.csv", sep = ',')
```


```python
absolute_error_data = pd.DataFrame({'Actual':all_data['Actual'],
                               'OLS(Log)':abs(all_data['Actual'] - all_data['OLS(Log)']),
                               'LASSO(Log)':abs(all_data['Actual'] - all_data['LASSO(Log)']),
                              'kNN(Log)':abs(all_data['Actual'] - all_data['kNN(Log)']),
                             'SVM(Linear Kernel)':abs(all_data['Actual'] - all_data['SVM(Linear Kernel)']),
                              'RandomForest(Log)':abs(all_data['Actual'] - all_data['RandomForest(Log)'])})
absolute_error_data.to_csv("AbsoluteErrorTestModelDataTopFive.csv", sep = ",")
df_test_keep.to_csv("TestData.csv", sep = ",")
```
